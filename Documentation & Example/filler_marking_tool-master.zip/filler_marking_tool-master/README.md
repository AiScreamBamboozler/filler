## Filler Marking Tool

The run_tests.sh bash script simply play filler against all the bots in the order
they appear on the marking sheet.
