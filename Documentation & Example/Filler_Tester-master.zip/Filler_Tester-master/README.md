# Filler_Tester
This is a tester for the Filler WeThinkCode_ Project. This is adapted off darklink41's tester.

To use it:

- Run make.
- Copy filler_tester into your resources folder.
- Run filler_tester.
