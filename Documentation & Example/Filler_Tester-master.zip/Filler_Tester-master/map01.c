/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   map01.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dpoulter <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/07/18 11:13:41 by dpoulter          #+#    #+#             */
/*   Updated: 2018/07/18 11:13:42 by dpoulter         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "sfiller.h"

void	map01(t_prm *prm, char player[21])
{
	printf("\n\n-------------------------------------------\n");
	printf("|------------------MAP 1------------------|\n");
	printf("-------------------------------------------\n\n");
	if (prm->nb1)
		map01p1(prm, player);
	if (prm->nb2)
		map01p2(prm, player);
}

void	map01p1(t_prm *prm, char player[21])
{
	int		i;
	int		j;
	int		score;
	int		num;
	double	percentage;

	i = 0;
	while (i < prm->player_nb)
	{
		score = 0;
		j = 0;
		num = 0;
		while (j < prm->nb1)
		{
			sprintf(prm->entry, "ruby filler_vm -q -f maps/map01 -p1 \
			players/%s.filler -p2 players/%s.filler > /dev/null", player, \
					prm->player_lst[i]);
			system(prm->entry);
			bzero(prm->entry, 149);
			prm->fd = open("filler.trace", O_RDONLY);
			read(prm->fd, prm->buf, 4096);
			num++;
			percentage = (double)(((double)num / (double)prm->nb1) * 100);
			show_status(percentage);
			if (strstr(prm->buf, player) && !strstr(prm->buf, "Segfault"))
				score++;
			j++;
		}
		print_result(player, prm->player_lst[i], prm->nb1, score);
		i++;
	}
}

void	map01p2(t_prm *prm, char player[21])
{
	int		i;
	int		j;
	int		score;
	int		num;
	double	percentage;

	i = 0;
	while (i < prm->player_nb)
	{
		score = 0;
		j = 0;
		num = 0;
		while (j < prm->nb2)
		{
			sprintf(prm->entry, "ruby filler_vm -q -f maps/map01 -p1 \
			players/%s.filler -p2 players/%s.filler > /dev/null", \
			prm->player_lst[i], player);
			system(prm->entry);
			bzero(prm->entry, 149);
			prm->fd = open("filler.trace", O_RDONLY);
			read(prm->fd, prm->buf, 4096);
			num++;
			percentage = (double)(((double)num / (double)prm->nb2) * 100);
			show_status(percentage);
			if (strstr(prm->buf, player) && !strstr(prm->buf, "Segfault"))
				score++;
			j++;
		}
		print_result(prm->player_lst[i], player, prm->nb2, score);
		i++;
	}
}
